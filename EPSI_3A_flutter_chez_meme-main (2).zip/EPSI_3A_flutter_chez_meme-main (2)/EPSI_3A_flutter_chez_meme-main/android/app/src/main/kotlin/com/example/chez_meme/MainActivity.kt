package com.example.chez_meme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
